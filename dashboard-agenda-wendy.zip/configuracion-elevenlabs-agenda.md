# Configuración de ElevenLabs para controlar la agenda

El HTML ya registra siete **Client Tools**. Para que el agente pueda llamarlas, debes crear herramientas de tipo **Client** en ElevenLabs con los nombres y parámetros exactos que aparecen abajo. Los nombres distinguen mayúsculas y minúsculas.

## Requisitos del widget

- El agente debe estar público y con la autenticación del widget desactivada.
- En **Security → Allowlist**, agrega: `mi-semana-en-balance-wendy.zegg.chatgpt.site`.
- Activa **Wait for response / Block conversation** en cada herramienta para que el agente espere y utilice el resultado real.

## 1. consultarAgenda

**Descripción:** Consulta los eventos y tareas guardados en el navegador del usuario. Usar antes de responder qué hay en la agenda y antes de editar o eliminar elementos para obtener sus IDs.

| Parámetro | Tipo | Obligatorio | Descripción |
|---|---|---:|---|
| `periodo` | string | No | Uno de: `hoy`, `manana`, `esta_semana`, `proxima_semana`, `rango`. Predeterminado: `hoy`. |
| `fecha_inicio` | string | No | Para `rango`, fecha inicial en formato `YYYY-MM-DD`. |
| `fecha_fin` | string | No | Para `rango`, fecha final en formato `YYYY-MM-DD`. |
| `incluir_completadas` | boolean | No | Indica si debe incluir tareas completadas. |

## 2. crearEvento

**Descripción:** Crea un evento nuevo después de confirmar con el usuario el título, la fecha y el horario.

| Parámetro | Tipo | Obligatorio | Descripción |
|---|---|---:|---|
| `titulo` | string | Sí | Nombre del evento. |
| `fecha` | string | Sí | Fecha en formato `YYYY-MM-DD`. |
| `hora_inicio` | string | Sí | Hora en formato de 24 horas `HH:MM`. |
| `hora_fin` | string | Sí | Hora en formato de 24 horas `HH:MM`. |
| `categoria` | string | No | `trabajo`, `escuela` o `personal`. |
| `prioridad` | string | No | `alta`, `media` o `baja`. |
| `lugar` | string | No | Lugar o modalidad. |
| `notas` | string | No | Información adicional. |

## 3. actualizarEvento

**Descripción:** Modifica un evento existente. Primero debe usarse `consultarAgenda` para identificar el ID correcto.

| Parámetro | Tipo | Obligatorio | Descripción |
|---|---|---:|---|
| `id` | string | Sí | ID devuelto por `consultarAgenda`. |
| `titulo` | string | No | Nuevo título. |
| `fecha` | string | No | Nueva fecha `YYYY-MM-DD`. |
| `hora_inicio` | string | No | Nueva hora inicial `HH:MM`. |
| `hora_fin` | string | No | Nueva hora final `HH:MM`. |
| `categoria` | string | No | `trabajo`, `escuela` o `personal`. |
| `prioridad` | string | No | `alta`, `media` o `baja`. |
| `lugar` | string | No | Nuevo lugar. |
| `notas` | string | No | Nuevas notas. |

## 4. eliminarEvento

**Descripción:** Elimina un evento solo después de recibir confirmación explícita del usuario.

| Parámetro | Tipo | Obligatorio | Descripción |
|---|---|---:|---|
| `id` | string | Sí | ID devuelto por `consultarAgenda`. |
| `confirmado` | boolean | Sí | Debe enviarse como `true` únicamente después de una confirmación explícita. |

## 5. crearTarea

**Descripción:** Crea una tarea nueva en el dashboard.

| Parámetro | Tipo | Obligatorio | Descripción |
|---|---|---:|---|
| `titulo` | string | Sí | Nombre de la tarea. |
| `fecha_limite` | string | No | Fecha límite `YYYY-MM-DD`. |
| `categoria` | string | No | `trabajo`, `escuela` o `personal`. |
| `prioridad` | string | No | `alta`, `media` o `baja`. |

## 6. actualizarTarea

**Descripción:** Edita o completa una tarea. Primero debe usarse `consultarAgenda` para identificar el ID correcto.

| Parámetro | Tipo | Obligatorio | Descripción |
|---|---|---:|---|
| `id` | string | Sí | ID devuelto por `consultarAgenda`. |
| `titulo` | string | No | Nuevo título. |
| `fecha_limite` | string | No | Nueva fecha límite `YYYY-MM-DD`; enviar una cadena vacía para quitarla. |
| `categoria` | string | No | `trabajo`, `escuela` o `personal`. |
| `prioridad` | string | No | `alta`, `media` o `baja`. |
| `completada` | boolean | No | `true` para completar, `false` para reabrir. |

## 7. eliminarTarea

**Descripción:** Elimina una tarea solo después de recibir confirmación explícita del usuario.

| Parámetro | Tipo | Obligatorio | Descripción |
|---|---|---:|---|
| `id` | string | Sí | ID devuelto por `consultarAgenda`. |
| `confirmado` | boolean | Sí | Debe enviarse como `true` únicamente después de una confirmación explícita. |

## Instrucción recomendada para el agente

```text
Eres un asistente de organización conectado al dashboard de la usuaria.

Cuando te pregunten qué hay en la agenda, usa consultarAgenda antes de responder. Para editar, completar o eliminar un elemento, consulta primero la agenda para obtener su ID exacto. Antes de crear o modificar, resume el cambio y confirma los datos importantes. Antes de eliminar, solicita confirmación explícita y solo entonces envía confirmado=true.

Usa fechas YYYY-MM-DD y horas HH:MM en formato de 24 horas. No afirmes que una acción se realizó hasta recibir una respuesta ok=true de la herramienta. Si una herramienta devuelve ok=false, explica el error y pide únicamente el dato necesario para corregirlo.

Los datos pertenecen al navegador actual; no prometas sincronización con otros dispositivos.
```

## Pruebas sugeridas

1. “¿Qué tengo hoy en mi agenda?”
2. “Agrega una reunión de Vertiche mañana de 16:00 a 17:00, prioridad alta.”
3. “¿Qué tareas tengo esta semana?”
4. “Marca como completada la tarea de materiales para clase.”
5. “Elimina la reunión de Vertiche.” El agente debe pedir confirmación antes de eliminarla.

